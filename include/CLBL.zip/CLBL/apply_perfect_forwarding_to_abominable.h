#ifndef CLBL_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE
#define CLBL_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE

#define __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(qualifiers) \
    template<typename Return, typename... Args> \
    struct apply_perfect_forwarding_t<Return(Args...) qualifiers> { \
        using type = Return(Args&&...) qualifiers; \
    }

#define __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(qualifiers) \
    template<typename Return, typename... Args> \
    struct apply_perfect_forwarding_t<Return(Args...,...) qualifiers> { \
        using type = Return(Args&&...,...) qualifiers; \
    }

namespace clbl {

    //primary template fails silently
    template<typename Other> struct apply_perfect_forwarding_t { using type = Other; };

    template<typename Return, typename... Args>
    struct apply_perfect_forwarding_t<Return(Args...)> { using type = Return(Args&&...); };

    template<typename Return, typename... Args>
    struct apply_perfect_forwarding_t<Return(Args..., ...)> { using type = Return(Args&&..., ...); };

    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(&);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(&&);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(const);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(volatile);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(const volatile);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(const &);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(volatile &);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(const volatile &);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(const &&);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(volatile &&);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE(const volatile &&);

    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(&);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(&&);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(const);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(volatile);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(const volatile);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(const &);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(volatile &);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(const volatile &);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(const &&);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(volatile &&);
    __SPECIALIZE_APPLY_PERFECT_FORWARDING_TO_ABOMINABLE_ELLIPSES(const volatile &&);

    template<typename T>
    using apply_perfect_forwarding = typename apply_perfect_forwarding_t<T>::type;
}

#endif