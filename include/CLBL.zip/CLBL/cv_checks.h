#ifndef CLBL_CV_CHECKS_H
#define CLBL_CV_CHECKS_H

#include<type_traits>
#include <boost/hana.hpp>

//sorry to anyone reading this - this is terribly tricky, and is very hard without macros

namespace hana = boost::hana;

namespace clbl {




}

#endif